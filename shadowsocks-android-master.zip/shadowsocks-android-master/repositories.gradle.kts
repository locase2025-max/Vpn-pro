repositories {
    google()
    mavenCentral()
}
