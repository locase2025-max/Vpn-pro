include(":core", ":plugin", ":mobile", ":tv")
